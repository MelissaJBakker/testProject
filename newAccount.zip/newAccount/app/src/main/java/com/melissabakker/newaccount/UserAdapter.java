package com.melissabakker.newaccount;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;

public class UserAdapter extends ArrayAdapter<User> {

        FirebaseFirestore fStore = FirebaseFirestore.getInstance();
        String userID;
        User user;


        public UserAdapter(Context context, ArrayList<User> users) {
            super(context, 0, users);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_user, parent, false);
            }


            TextView email = (TextView) convertView.findViewById(R.id.userEmail);
            TextView username = (TextView) convertView.findViewById(R.id.userName);
            TextView role = (TextView) convertView.findViewById(R.id.userRole);
            Button delBtn = (Button) convertView.findViewById(R.id.button2);

            user = getItem(position);

            email.setText(user.getEmail());
            username.setText(user.getUsername());
            role.setText(user.getRole());


            delBtn.setTag(position);
            delBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //int position = (Integer) view.getTag();

                    DocumentReference doc = fStore.collection("emailID").document(user.getEmail());
                    doc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                            userID = value.getString("userID");
                        }
                    });
                    DocumentReference userDoc = fStore.collection("users").document(userID);
                    userDoc.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Log.d("Main", userID + " user is deleted.");
                            }
                            else{
                                Log.d("Main", "Error! " + userID + " user is not deleted.");
                            }
                        }
                    });
                    doc.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Log.d("Main", userID + " emailID is deleted.");
                            }
                            else{
                                Log.d("Main", "Error! " + userID + " emailID is not deleted.");
                            }
                        }
                    });
                    if (user.getRole().equals("Employee")) {
                        DocumentReference bServices = fStore.collection("branchServices").document(userID);
                        bServices.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Log.d("Main", userID + " branchServices is deleted.");
                                }
                                else{
                                    Log.d("Main", "Error! " + userID + " branchServices is not deleted.");
                                }
                            }
                        });
                    }
            }});
            return convertView;
        }
}
