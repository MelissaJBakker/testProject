package com.melissabakker.newaccount;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AddSchedule extends AppCompatActivity {

    Button btnSkip, btnSched;
    SwitchCompat mondaySwitch, tuesdaySwitch, wednesdaySwitch, thursdaySwitch, fridaySwitch, saturdaySwitch, sundaySwitch;
    EditText monStart, monEnd, tuesStart, tuesEnd, wedStart, wedEnd, thursStart, thursEnd, friStart, friEnd, satStart, satEnd, sunStart, sunEnd;
    ArrayList<SwitchCompat> switches;
    ArrayList<EditText> startsAndEnds;
    ArrayList<String> timeRanges;

    private FirebaseAuth firebaseAuth;
    FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_schedule);


        /** Input definition **/
        monStart = (EditText) findViewById(R.id.MondayStart);
        monEnd = (EditText) findViewById(R.id.MondayEnd);
        tuesStart = (EditText) findViewById(R.id.TuesdayStart);
        tuesEnd = (EditText) findViewById(R.id.TuesdayEnd);
        wedStart = (EditText) findViewById(R.id.WednesdayStart);
        wedEnd = (EditText) findViewById(R.id.WednesdayStart);
        thursStart = (EditText) findViewById(R.id.ThursdayStart);
        thursEnd = (EditText) findViewById(R.id.ThursdayEnd);
        friStart = (EditText) findViewById(R.id.FridayStart);
        friEnd = (EditText) findViewById(R.id.FridayEnd);
        satStart = (EditText) findViewById(R.id.SaturdayStart);
        satEnd = (EditText) findViewById(R.id.SaturdayEnd);
        sunStart = (EditText) findViewById(R.id.SundayStart);
        sunEnd = (EditText) findViewById(R.id.SundayEnd);

        btnSkip = (Button) findViewById(R.id.btnSkip);
        btnSched = (Button) findViewById(R.id.btnSched);

        mondaySwitch = (SwitchCompat) findViewById(R.id.Monday);
        tuesdaySwitch = (SwitchCompat) findViewById(R.id.Tuesday);
        wednesdaySwitch = (SwitchCompat) findViewById(R.id.Wednesday);
        thursdaySwitch = (SwitchCompat) findViewById(R.id.Thursday);
        fridaySwitch = (SwitchCompat) findViewById(R.id.Friday);
        saturdaySwitch = (SwitchCompat) findViewById(R.id.Saturday);
        sundaySwitch = (SwitchCompat) findViewById(R.id.Sunday);


        startsAndEnds = new ArrayList<>();
        //i=0
        startsAndEnds.add(monStart); //0
        startsAndEnds.add(monEnd); //1
        //i=1
        startsAndEnds.add(tuesStart); //2
        startsAndEnds.add(tuesEnd); //3
        //i=2
        startsAndEnds.add(wedStart); //4
        startsAndEnds.add(wedEnd); //5
        //i=3
        startsAndEnds.add(thursStart); //6
        startsAndEnds.add(thursEnd); //7
        //i=4
        startsAndEnds.add(friStart); //8
        startsAndEnds.add(friEnd); //9
        //i=5
        startsAndEnds.add(satStart); //10
        startsAndEnds.add(satEnd); //11
        //i=6
        startsAndEnds.add(sunStart); //12
        startsAndEnds.add(sunEnd); //13


        firebaseAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        /** Making an arrayList of switches for computations. **/
        switches = new ArrayList<>();
        switches.add(mondaySwitch);
        switches.add(tuesdaySwitch);
        switches.add(wednesdaySwitch);
        switches.add(thursdaySwitch);
        switches.add(fridaySwitch);
        switches.add(saturdaySwitch);
        switches.add(sundaySwitch);

        for (int i = 0; i < 7; i++) {
            if (switches.get(i).isChecked()) {
                startsAndEnds.get(i * 2).setVisibility(View.VISIBLE);
                startsAndEnds.get((i * 2) + 1).setVisibility(View.VISIBLE);
            }
        }


        /** Pressing skip will send you back the welcome page without adding
         * or editing values **/
        btnSkip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), Welcome.class);
                startActivity(intent);
            }
        });

        btnSched.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i < 7; i++) {
                    String t1= startsAndEnds.get(i * 2).getText().toString().trim();
                    String t2= startsAndEnds.get((i * 2)+1).getText().toString().trim();
                    if (switches.get(i).isChecked()) {
                        try {
                            if (!checkTime(t1, t2).equals("")) {
                                timeRanges.add(checkTime(t1, t2));
                            }
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        timeRanges.add("");
                    }
                }
                String userID=firebaseAuth.getCurrentUser().getUid();
                DocumentReference branchSchedule = fStore.collection("branchSchedule").document(userID);
                Map<String, Object> schedule= new HashMap<>();
                schedule.put("Monday", timeRanges.get(0));
                schedule.put("Tuesday", timeRanges.get(1));
                schedule.put("Wednesday", timeRanges.get(2));
                schedule.put("Thursday", timeRanges.get(3));
                schedule.put("Friday", timeRanges.get(4));
                schedule.put("Saturday", timeRanges.get(5));
                schedule.put("Sunday", timeRanges.get(6));
                branchSchedule.set(schedule);
            }
        }
        );
    }

    /**
     * Method to check that neither time is empty, and that the second is greater than the first.
     * Then converts to a string range for storage in the firestore.
     *
     * @param time1 the first time string
     * @param time2 the second time string
     * @return string for their range in format (hh:mm)-(hh:mm)
     */
    public String checkTime(String time1, String time2) throws ParseException {

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

        Date t1 = sdf.parse(time1);
        Date t2 = sdf.parse(time2);

        if (time1.isEmpty() || time2.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Error! Missing fields.", Toast.LENGTH_SHORT);
        } else if (t1.after(t2) || t1.equals(t2)) {
            Toast.makeText(getApplicationContext(), "Error! Invalid time interval.", Toast.LENGTH_SHORT).show();
        } else {
            return (t1 + " - " + t2);
        }
        return "";
    }
}